# Dúnedain Data Atlas

An independent analytical portfolio by Zendevve: 125 rulers plus 28 connecting relatives, 129 tenures, seven political institutions. The app explores referenced records through a timeline, ruler explorer, individual profiles, six analyses, comparisons, a curated lineage graph and a real DuckDB-Wasm SQL lab.

## Local development

Node 22.13+ and Python 3.10+ are required.

```sh
corepack pnpm install --frozen-lockfile
python -m pip install -r requirements.txt
python analytics/pipeline.py
python -m unittest discover -s analytics/tests -v
node tests/sql-engine.mjs
node tests/app-logic.mjs
node tests/render-app.cjs
pnpm dev
```

The Sites checkout uses pnpm; its lockfile pins the hosted build. Outside Sites, install using pnpm for identical dependencies. The frontend uses React, TypeScript, the Next App Router API through Vinext, Tailwind and the included accessible UI primitives. It builds a Cloudflare Worker for Sites hosting. It is not a Vercel deployment.

## Reproducible data

`data/raw/` is the source of truth. `analytics/seed.py` documents the initial manual transcription and is not required for normal rebuilds. Edit normalized records directly, then execute `analytics/pipeline.py`. It validates relational references, chronology and field provenance before producing Parquet, CSV, JSON and the frontend bundle. `analytics/tests/` exercises cross-age calculations, interrupted reigns, exceptional records and acyclic parentage.

Tables: persons, aliases, houses, realms, offices, reigns, relationships, events, sources and field_sources. Derived marts: mart_ruler_reigns, mart_realm_summary and mart_succession. SQL aliases `rulers` and `ruler_reigns` are provided.

The browser initializes DuckDB only after Run is selected, registers local Parquet files, disables external access and accepts one SELECT/WITH statement. Results are capped at 1,000 rows. A 20-second timeout terminates expensive queries and resets the worker (60 seconds on initial engine load). The SQL-engine integration test runs the actual WebAssembly build against all 13 Parquet tables. Regression checks cover filters and accent-insensitive search, read-only SQL validation, all example queries, failure recovery, the result limit, engine asset integrity, and server rendering of all 161 routes with 167 internal links/download targets. Browser interaction and visual QA remain unverified because browser testing was unavailable.

## Method and exclusions

Year-level chronology adds 3441 for TA and 6462 for FA; durations are end minus start. First Age births are not normalized. The Fourth Age boundary is a year-level approximation, not exact calendar arithmetic. A person is distinct from a tenure. Eldacar's ten-year exile is excluded. Overlapping southern co-rulers and overlordship, usurpers, titular rule and Aranarth's uncertain accession are excluded from default descriptive summaries. All remain inspectable.

Source tables were checked against secondary references, with underlying primary works cited for subsequent edition-level review. No claim is made of a full primary-source audit. All 125 ruler life records and ancestral branches are reviewed, with 123 known lifespans. Eärnur and Ar-Pharazôn retain unresolved death dates. Supporting relatives connect collateral branches; ancestor edges preserve unnamed intervening generations. Elros and Aragorn use reported lifespans of 500 and 210. The event list is selective and is not a measure of importance. No causal or predictive claims are made.

## Routes

`/`, `/timeline`, `/rulers`, `/rulers/[slug]`, `/analysis`, `/compare`, `/lineage`, `/sql`, `/methodology`.

## Source attribution

Tolkien Gateway institutional lists (accessed 2026-09-28) and Zarkanya's Appendix 1 recorded Númenórean life dates; source URLs and field associations are included in `data/raw/sources.json` and `field_sources.json`. No estimated Andúnië lifespans or narrative prose are imported. Raw data and derivatives are distributed under CC BY-SA 4.0 with attribution; application source is MIT licensed. Tolkien's underlying works, names and trademarks remain those of their respective owners.

Unofficial educational project. Not affiliated with the Tolkien Estate or adaptation rights holders.

## Current coverage limits

The seven principal institutions are represented, including all 26 Ruling Stewards. Faramir's short transitional stewardship is excluded from that count. Cardolan/Rhudaur royal fragments, genealogy beyond the included rulers and their connecting ancestors, complete event curation and an independent primary-edition audit remain outside this release. No fabricated records fill those gaps.
